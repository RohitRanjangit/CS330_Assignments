#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <wait.h>
#include <sys/types.h>
#include <sys/stat.h>

#define ROCK        0 
#define PAPER       1 
#define SCISSORS    2 

#define STDIN 		0
#define STDOUT 		1
#define STDERR		2


#include "gameUtils.h"

int getWalkOver(int numPlayers); // Returns a number between [1, numPlayers]


int main(int argc, char *argv[])
{
	if(argc!=2 && argc!=4){
		// perror("Invalid number of arguments");
		exit(-1);
	}
	int nround = 10;
	if(argc == 4 && argv[1][0] == '-' && argv[1][1] == 'r'){
		nround = atoi(argv[2]);
	}
	// printf("Number of round: %d\n",nround);
	char* infile;
	if(argc ==2){
		infile = argv[1];
	}else{
		infile = argv[3];
	}
	int infd = open(infile, O_RDONLY);
	if(infd < 0){
		// perror("can't open input file or wrong name provided");
		exit(-1);
	}
	char nplay[64], cchar;
	int ppos =0;
	do{
		if((read(infd , &cchar, 1)) <= 0){
			// perror("can't read input files");
			exit(-1);
		}
		nplay[ppos++] = cchar;
	}while(cchar != '\n');
	nplay[ppos-1] = '\0';
	int nplayers = atoi(nplay);
	// printf("Number of players: %d\n" , nplayers);
	char executables[nplayers][101];
	for(int i=0;i<nplayers;i++){
		int npos =0;
		do{
			if((read(infd , &cchar, 1)) <= 0){
				// perror("can't read input files");
				exit(-1);
			}
			executables[i][npos++] = cchar;
		}while(cchar != '\n');
		executables[i][npos-1] = '\0';
		// printf("%s\n", executables[i]);
	}
	int active[nplayers] , nactive = nplayers;
	for(int i=0;i<nplayers;i++){
		active[i] =1;
	}
	int std_in[nplayers][2], std_out[nplayers][2];
	pid_t pid , cpid[nplayers];
	for(int i=0;i<nplayers;i++){
		if(pipe(std_in[i]) < 0){
			// perror("pipe failed");
			exit(-1);
		}
		if(pipe(std_out[i]) < 0){
			// perror("pipe failed");
			exit(-1);
		}
		cpid[i] = fork();
		if(!cpid[i]){
			close(std_in[i][1]);
			close(std_out[i][0]);
			if(dup2(std_in[i][0],0) < 0){
				// perror("error in dup2");
				exit(-1);
			}
			if(dup2(std_out[i][1],1) < 0){
				// perror("error in dup2");
				exit(-1);
			}
			char* paramList[] = {executables[i], NULL};
			if(execv(executables[i] , paramList)){
				// perror("execv error");
				close(std_in[i][0]);
				close(std_out[i][1]);
				exit(-1);
			}
			// perror("execv error");
			close(std_in[i][0]);
			close(std_out[i][1]);
			exit(-1);
		}
		close(std_in[i][0]);
		close(std_out[i][1]);
	}
	
	while(nactive>1){
		
		int walkOver = (nactive %2 ? getWalkOver(nactive):-1);
		int pc =0,pcnt =0;
		int activePlayer[nactive - (int)(nactive%2)];
		for(int i=0;i<nplayers;i++){
			if(active[i]){
				pc++;
				if(pc!= walkOver){
					activePlayer[pcnt++] = i;
				}
				if(pc <nactive){
					printf("p%d ", i);
				}else{
					printf("p%d\n", i);
				}
			}
		}
		for(int i=0;i<pcnt;i+=2){
			int pid1 = activePlayer[i], pid2 = activePlayer[i+1];
			int score1 =0, score2 =0;
			for(int k=0;k<nround;k++){
				char oc1, oc2;
				if(write(std_in[pid1][1],"GO",3) <= 0){
					// perror("write error");
					exit(-1);
				}
				if(read(std_out[pid1][0], &oc1,1) <= 0){
					// perror("read error");
					exit(-1);
				}
				if(write(std_in[pid2][1],"GO",3) <= 0){
					// perror("write error");
					exit(-1);
				}
				if(read(std_out[pid2][0], &oc2,1) <= 0){
					// perror("read error");
					exit(-1);
				}
				if((oc1 == '1' && oc2 == '0') || (oc1 == '2'&& oc2=='1') || (oc1 == '0' && oc2 == '2'))score1++;
				else if((oc2 == '1' && oc1 == '0') || (oc2 == '2'&& oc1=='1') || (oc2 == '0' && oc1 == '2'))score2++;
			}
			if(score1 == score2){
				if(pid1 < pid2){
					active[pid2] =0;
					close(std_in[pid2][0]);
					close(std_out[pid2][1]);
				}else{
					active[pid1] =0;
					close(std_in[pid1][0]);
					close(std_out[pid1][1]);
				}
			}else if(score1 > score2){
				active[pid2] =0;
				close(std_in[pid2][0]);
				close(std_out[pid2][1]);
			}else{
				active[pid1] =0;
				close(std_in[pid1][0]);
				close(std_out[pid1][1]);
			}
			nactive--;
		}
	}
	for(int i=0;i<nplayers;i++){
		if(active[i]){
			printf("p%d", i);
			break;
		}
	}
	return 0;
}
