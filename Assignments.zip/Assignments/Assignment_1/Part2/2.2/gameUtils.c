int getWalkOver(int numPlayers)
{
	return 1; // The first active player gets walkthrough
}